Modification of the calculator code, available at the tutoria as T08-code.zip,
to illustrate how it is possible to bypass ANTLR's default error messages and provide
our own messages.

Just showing the visitor example.

-- Fernando Lobo
